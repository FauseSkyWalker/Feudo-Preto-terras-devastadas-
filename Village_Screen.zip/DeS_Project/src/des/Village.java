package des;

public class Village {
	
	
	Village_UI ui = new Village_UI(this);
	
	
	public static void main (String[] args) {
		
		
		
		
		new Village();
	}
	public Village() {
		
	}

}
