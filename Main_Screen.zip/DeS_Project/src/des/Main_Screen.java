package des;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class Main_Screen {

	
	Main_Screen_UI ui = new Main_Screen_UI(this);
	
public static void main (String[] args) {
		
	new Main_Screen();
	//Menu.setVisible(true);
	}

public Main_Screen(){}













}
